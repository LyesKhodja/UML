public class PoweredActivity extends Activity {
    private Equipment equipment;
    private double weight;

    public PoweredActivity(double distance, Mode mode, Athlete athlete, Equipment equipment, double weight) {
        super(distance, mode, athlete);
        this.equipment = equipment;
        this.weight = weight;
    }

    public Equipment getEquipment() {
        return equipment;
    }

    public void setEquipment(Equipment equipment) {
        this.equipment = equipment;
    }

    @Override
    public double getCaloriesBurned() {
        return getDistance() * (50 + (weight * 0.1));
    }

    @Override
    public String toString() {
        return super.toString() + " using " + equipment.getName();
    }
}