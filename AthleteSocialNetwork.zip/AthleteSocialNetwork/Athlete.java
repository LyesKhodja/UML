import java.util.ArrayList;

public class Athlete {
    private String name;
    private Gender gender;
    private ArrayList<Activity> activities;

    public Athlete(String name, Gender gender) {
        this.name = name;
        this.gender = gender;
        this.activities = new ArrayList<>();
    }

    public String getName() {
        return name;
    }

    public Gender getGender() {
        return gender;
    }

    public void addActivity(Activity a) {
        if (a != null) {
            activities.add(a);
        }
    }

    public double getTotalDistance() {
        double total = 0;
        for (Activity a : activities) {
            total += a.getDistance();
        }
        return total;
    }

    public double getTotalCalories() {
        double total = 0;
        for (Activity a : activities) {
            total += a.getCaloriesBurned();
        }
        return total;
    }

    @Override
    public String toString() {
        return "Athlete: " + name + " (" + gender + ")";
    }
}