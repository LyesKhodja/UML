public class Activity {
    private double distance;
    private Mode mode;
    private Athlete athlete;

    public Activity(double distance, Mode mode, Athlete athlete) {
        if (distance < 0) {
            throw new IllegalArgumentException("Distance cannot be negative.");
        }
        this.distance = distance;
        this.mode = mode;
        this.athlete = athlete;
    }

    public double getDistance() {
        return distance;
    }

    public Mode getMode() {
        return mode;
    }

    public Athlete getAthlete() {
        return athlete;
    }

    public double getCaloriesBurned() {
        return distance * 50; // Base formula, can adjust based on mode later
    }

    @Override
    public String toString() {
        return mode + " activity for " + distance + " km by " + athlete.getName();
    }
}